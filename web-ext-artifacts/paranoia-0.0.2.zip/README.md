# paranoia

## Licenses
File sha256.js is distributed under the Webtoolkit license.

All other files are distributed under the MPL-2.0 License

## Purpose
Demonstrate the capabilities of add-ons and JavaScript.
### Present Security Information about Web pages and their resources
### Allow to block unwanted content
### Allow to block unwanted network interaction
